import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import javax.swing.*;
import java.util.Map;

public class TestCases  {


    @Test
    public void TestcaseforTask2() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("https://ksrtc.in/oprs-web/guest/home.do?h=1");

        WebElement FromPlaceName = driver.findElement(By.id("fromPlaceName"));
        FromPlaceName.sendKeys("CHIKKAMAGALURU");
        Thread.sleep(1000);
        FromPlaceName.sendKeys(Keys.TAB);


        WebElement ToPlaceTextbox = driver.findElement(By.id("toPlaceName"));
        ToPlaceTextbox.sendKeys("BENGALURU");
        Thread.sleep(1000);
        ToPlaceTextbox.sendKeys(Keys.TAB);

        WebElement ArrivalDate = driver.findElement(By.id("txtJourneyDate"));
        ArrivalDate.click();

        WebElement NextMonthButton = driver.findElement(By.xpath("//a[@data-handler='next']"));
        NextMonthButton.click();
        Thread.sleep(1000);


        WebElement FirstDay = driver.findElement(By.xpath("//a[contains(@class,'ui-state-default')]"));
        FirstDay.click();
        Thread.sleep(1000);

        WebElement SearchButton = driver.findElement(By.className("btn-booking"));
        SearchButton.click();
        Thread.sleep(5000);

        WebElement Selectseat = driver.findElement(By.xpath("(//input[@type='button' and @id='SrvcSelectBtnForward0'])[2]"));
        Selectseat.click();
        Thread.sleep(2000);

        WebElement SelectSeatNumber = driver.findElement(By.xpath("//*[contains(@class,'availSeatClass')]"));
        SelectSeatNumber.click();

        //WebElement SelectTheBoardingPointarrow = driver.findElement(By.id("Forwardboarding-tab"));
        //SelectTheBoardingPointarrow.click();

        WebElement SelectTheBoardingPoint = driver.findElement(By.id("Forward-1467469338690"));
        SelectTheBoardingPoint.click();

        WebElement SelectTheDroppingPoint = driver.findElement(By.id("Forward-1467467616730"));
        SelectTheDroppingPoint.click();

        WebElement MobileNumberTextBox = driver.findElement(By.id("mobileNo"));
        MobileNumberTextBox.sendKeys("6789125987");

        WebElement EmailTextBox = driver.findElement(By.id("email"));
        EmailTextBox.sendKeys("raniaelsayed@gmail.com");



        WebElement PassengerDetails = driver.findElement(By.xpath("//a[contains(text(), 'Passenger Details')]"));
        PassengerDetails.click();
        Thread.sleep(2000);

        WebElement PassengerNameTextBox = driver.findElement(By.id("passengerNameForward0"));
        PassengerNameTextBox.sendKeys("Mohamed");

        WebElement GenderSelectBox = driver.findElement(By.id("genderCodeIdForward0"));
        Select selectGender = new Select(GenderSelectBox);
        selectGender.selectByVisibleText("MALE");

        WebElement PassengerAgeTextBox = driver.findElement(By.id("passengerAgeForward0"));
        PassengerAgeTextBox.sendKeys("25");


        WebElement ConcessionSelectBox = driver.findElement(By.id("concessionIdsForward0"));
        Select selectConssion = new Select(ConcessionSelectBox);
        selectConssion.selectByVisibleText("GENERAL PUBLIC");

        WebElement NationalitySelectBox = driver.findElement(By.id("nationalityForward0"));
        Select selectNationality = new Select(NationalitySelectBox);
        selectNationality.selectByVisibleText("Egypt");


        WebElement PassportNumberTextBox = driver.findElement(By.id("passportNoForward0"));
        PassportNumberTextBox.sendKeys("123456789100");

        WebElement IndiaAddressTextBox = driver.findElement(By.id("foreignerAddressForward0"));
        IndiaAddressTextBox.sendKeys("A 302, Sky High ,Mumbai");

        WebElement BirthDate = driver.findElement(By.id("dobForward0"));
        BirthDate.sendKeys("26/05/1998");
        BirthDate.sendKeys(Keys.ENTER);


    }
    }



